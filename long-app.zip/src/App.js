import AppRoutes from "./routes/Routes";
import "./App.css";

function App() {
  return (
    <>
      <AppRoutes />
    </>
  );
}

export default App;
